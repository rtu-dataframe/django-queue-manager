from django.apps import AppConfig


class DjangoQueueManagerConfig(AppConfig):
    name = 'django_queue_manager'
